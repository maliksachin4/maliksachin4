﻿-----------------------------------------------------------------------

Forcepoint Decryption Utility v8.5.x

Release Notes updated:   22 December 2017


-----------------------------------------------------------------------

Contents
     1. Overview
     2. Using the Forcepoint Decryption Utility v8.5.x 
     3. Technical Support 

-----------------------------------------------------------------------
1.  Overview
-----------------------------------------------------------------------

The documents on this removable media device have been encrypted by Forcepoint
DLP Endpoint. To decrypt the files, run the decryption utility, wsdecrypt.exe,
that has been included. To access the files, you must supply a password. This 
is the password that you (or an endpoint user) configured using the Set Encryption
Password feature in the Forcepoint DLP Endpoint software.

-----------------------------------------------------------------------
2.  Using the Forcepoint Decryption Utility v8.5.x
-----------------------------------------------------------------------

To decrypt files on a removable media device:

1. On the removable media device, run: 
      ForcepointDecryptionUtility.exe. 

2. Enter the encryption password when prompted. A dialog appears and displays lists
   of subdirectories and files on your system.

3. Navigate to the folder containing the encrypted files. By default, the files are
   on the removable media device.

4. Select the folders and files to decrypt, right-click, and select Save As.

5. Select the folder in which to save the decrypted files.

The Forcepoint Decryption Utility decrypts the files using the password you provided
and places them in this path.

Files that were encrypted with a different password are not decrypted.

Refer to the Forcepoint DLP Endpoint User Guide for more information on 
endpoint encryption.

-----------------------------------------------------------------------
3.  Technical Support
-----------------------------------------------------------------------

For assistance using the utility or for the required password, contact your
organization's IT department.


-----------------------------------------------------------------------
©1996-2017 Forcepoint LLC. All rights reserved.

Trademarks

Forcepoint(TM) is a trademark of Forcepoint LLC. Sureview(R), ThreatSeeker(R), TRITON(R), Sidewinder(R) and Stonesoft(R) are registered trademarks of Forcepoint LLC. Raytheon is a registered trademark of Raytheon Company. All other trademarks and registered trademarks are the property of their respective owners.
